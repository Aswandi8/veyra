import { redirect } from "next/navigation";

import { DataTablePagination } from "@/components/common/data-table/data-table-pagination";
import { DataTableProvider } from "@/components/common/data-table/data-table-provider";
import { DataTableToolbar } from "@/components/common/data-table/data-table-toolbar";

import { WebsiteMembersTable } from "@/components/websites/website-members-table";

import { TypographyH1, TypographyMuted } from "@/components/ui/typography";

import { AUTH_ROUTES } from "@/lib/auth/constants";

import type { DataTableFilter } from "@/lib/data-table/types";

import { membersQuerySchema } from "@/lib/members/schema";

import {
  getServerWebsiteMembers,
  getServerWebsiteRoles,
} from "@/lib/members/server";

import {
  getWebsiteAccess,
  hasWebsitePermission,
} from "@/lib/permissions/access";

import { PERMISSIONS } from "@/lib/permissions/constants";

import { getServerAdminAccess } from "@/lib/permissions/server";

interface MembersPageProps {
  params: Promise<{
    id: string;
  }>;

  searchParams: Promise<{
    q?: string;
    page?: string;
    limit?: string;
    role?: string;
  }>;
}

export default async function MembersPage({
  params,
  searchParams,
}: MembersPageProps) {
  const { id: websiteId } = await params;

  const access = await getServerAdminAccess();

  if (!access) {
    redirect(AUTH_ROUTES.dashboard);
  }

  const canRead = hasWebsitePermission(
    access,
    websiteId,
    PERMISSIONS.member.read,
  );

  if (!canRead) {
    redirect(AUTH_ROUTES.dashboard);
  }

  const canUpdate = hasWebsitePermission(
    access,
    websiteId,
    PERMISSIONS.member.update,
  );

  const canRemove = hasWebsitePermission(
    access,
    websiteId,
    PERMISSIONS.member.remove,
  );

  const website = getWebsiteAccess(access, websiteId);

  const raw = await searchParams;

  const parsed = membersQuerySchema.safeParse(raw);

  const query = parsed.success ? parsed.data : membersQuerySchema.parse({});

  const [members, rolesResponse] = await Promise.all([
    getServerWebsiteMembers(
      websiteId,
      query.q,
      query.page,
      query.limit,
      query.role,
    ),

    getServerWebsiteRoles(websiteId),
  ]);

  const roles = rolesResponse.data ?? [];

  const filters: readonly DataTableFilter[] =
    roles.length > 0
      ? [
          {
            key: "role",

            label: "Role",

            options: roles.map((role) => ({
              label: role.name.replaceAll("_", " "),

              value: role.id,
            })),
          },
        ]
      : [];

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <TypographyH1>Members</TypographyH1>

        <TypographyMuted>
          Manage members
          {website
            ? ` assigned to ${website.name}.`
            : " assigned to this website."}
        </TypographyMuted>
      </div>

      <DataTableProvider>
        <div className="space-y-6">
          <DataTableToolbar
            searchValue={query.q}
            searchPlaceholder="Search member name or email..."
            limit={query.limit}
            total={members.pagination.total}
            itemLabel="members"
            filters={filters}
            filterValues={{
              role: query.role,
            }}
          />

          <WebsiteMembersTable
            websiteId={websiteId}
            members={members.data}
            roles={roles}
            limit={query.limit}
            canUpdate={canUpdate}
            canRemove={canRemove}
            emptyMessage={
              query.q ? "No members match your search." : "No members found."
            }
          />

          <DataTablePagination
            pagination={members.pagination}
            basePath={`/websites/${websiteId}/members`}
            query={{
              q: query.q || undefined,

              role: query.role,
            }}
            itemLabel="members"
          />
        </div>
      </DataTableProvider>
    </div>
  );
}
