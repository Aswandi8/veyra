import type { AdminWebsiteStatus } from "@/lib/permissions/types";

export interface WebsiteStatistics {
  members: number;
  videos: number;
  categories: number;
  views: number;
  apiClients: number;
}

export interface WebsiteListItem {
  id: string;

  name: string;
  slug: string;

  description: string | null;
  domain: string | null;

  status: AdminWebsiteStatus;

  statistics: WebsiteStatistics;

  createdAt: string;
  updatedAt: string;
}

export interface WebsiteListResponse {
  success: boolean;

  data?: WebsiteListItem[];

  error?: string;
}

export interface WebsiteDetailResponse {
  success: boolean;

  data?: WebsiteListItem;

  error?: string;
}

export interface WebsiteMutationResponse {
  success: boolean;

  message?: string;
  error?: string;

  data?: {
    id: string;
    name: string;
    slug: string;

    description?: string | null;
    domain?: string | null;

    status?: AdminWebsiteStatus;

    createdAt?: string;
    updatedAt?: string;
  };
}
