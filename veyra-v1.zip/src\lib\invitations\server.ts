import { cache } from "react";

import { cookies } from "next/headers";

import { getCentralApiUrl } from "@/lib/auth/proxy";

import type { WebsiteInvitationsResponse } from "@/lib/invitations/types";

export const getServerWebsiteInvitations = cache(
  async (
    websiteId: string,
    q: string,
    page: number,
    limit: number,
    status?: string,
    role?: string,
  ): Promise<WebsiteInvitationsResponse> => {
    const cookieStore = await cookies();

    const cookieHeader = cookieStore
      .getAll()
      .map(({ name, value }) => `${name}=${value}`)
      .join("; ");

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
    });

    if (q) {
      params.set("q", q);
    }

    if (status) {
      params.set("status", status);
    }

    if (role) {
      params.set("role", role);
    }

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(
        websiteId,
      )}/invitations?${params.toString()}`,
      {
        method: "GET",

        headers: {
          Cookie: cookieHeader,

          Accept: "application/json",
        },

        cache: "no-store",
      },
    );

    if (!response.ok) {
      throw new Error(`Unable to load invitations (${response.status})`);
    }

    return (await response.json()) as WebsiteInvitationsResponse;
  },
);
