"use client";

import { Globe2 } from "lucide-react";

import { StatusBadge } from "@/components/common/status/status-badge";

import { Badge } from "@/components/ui/badge";

import { TypographyMuted } from "@/components/ui/typography";

import type { DataTableColumn } from "@/lib/data-table/types";

import { formatDateTime } from "@/lib/format/date";

import type { WebsiteListItem } from "@/lib/websites/types";

import { WebsiteActions } from "@/components/websites/website-actions";

interface CreateWebsitesColumnsOptions {
  canUpdate: boolean;
  canDelete: boolean;
}

export function createWebsitesColumns({
  canUpdate,
  canDelete,
}: CreateWebsitesColumnsOptions): readonly DataTableColumn<WebsiteListItem>[] {
  const columns: DataTableColumn<WebsiteListItem>[] = [
    {
      id: "website",
      header: "Website",

      cell: (website) => (
        <div className="flex items-center gap-3">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-lg border bg-muted/40">
            <Globe2 className="size-4 text-muted-foreground" />
          </div>

          <div className="min-w-0">
            <div className="truncate font-medium">{website.name}</div>

            <TypographyMuted className="truncate">
              /{website.slug}
            </TypographyMuted>
          </div>
        </div>
      ),
    },

    {
      id: "domain",
      header: "Domain",

      cell: (website) =>
        website.domain ? (
          <span className="whitespace-nowrap">{website.domain}</span>
        ) : (
          <TypographyMuted>—</TypographyMuted>
        ),
    },

    {
      id: "status",
      header: "Status",

      cell: (website) => <StatusBadge status={website.status} />,
    },

    {
      id: "members",
      header: "Members",

      cell: (website) => (
        <Badge variant="outline">{website.statistics.members}</Badge>
      ),
    },

    {
      id: "videos",
      header: "Videos",

      cell: (website) => (
        <TypographyMuted>{website.statistics.videos}</TypographyMuted>
      ),
    },

    {
      id: "createdAt",
      header: "Created",

      cell: (website) => (
        <TypographyMuted className="whitespace-nowrap">
          {formatDateTime(website.createdAt)}
        </TypographyMuted>
      ),
    },
  ];

  /*
   * Detail tetap bisa diakses meski user
   * tidak memiliki update/delete.
   */
  columns.push({
    id: "actions",

    header: <span className="sr-only">Actions</span>,

    headerClassName: "w-12 text-right",

    cellClassName: "w-12 text-right",

    cell: (website) => (
      <WebsiteActions
        website={website}
        canUpdate={canUpdate}
        canDelete={canDelete}
      />
    ),
  });

  return columns;
}
