import { ROLE_NAMES } from "@/lib/permissions/constants";

import type { AdminAccess, AdminWebsiteAccess } from "@/lib/permissions/types";

function getGlobalRoles(access: AdminAccess) {
  return Array.isArray(access.globalRoles) ? access.globalRoles : [];
}

function getGlobalPermissions(access: AdminAccess): string[] {
  return Array.isArray(access.globalPermissions)
    ? access.globalPermissions
    : [];
}

function getWebsites(access: AdminAccess): AdminWebsiteAccess[] {
  return Array.isArray(access.websites) ? access.websites : [];
}

export function isSuperAdmin(access: AdminAccess): boolean {
  if (access.superAdmin === true) {
    return true;
  }

  /*
   * Defensive fallback.
   *
   * Source of truth utama tetap
   * access.superAdmin.
   */
  return getGlobalRoles(access).some(
    (role) => role.name === ROLE_NAMES.superAdmin,
  );
}

export function hasGlobalRole(access: AdminAccess, roleName: string): boolean {
  if (isSuperAdmin(access)) {
    return roleName === ROLE_NAMES.superAdmin;
  }

  return getGlobalRoles(access).some((role) => role.name === roleName);
}

export function hasGlobalPermission(
  access: AdminAccess,
  permission: string,
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  return getGlobalPermissions(access).includes(permission);
}

export function getWebsiteAccess(
  access: AdminAccess,
  websiteId: string,
): AdminWebsiteAccess | null {
  return (
    getWebsites(access).find((website) => website.id === websiteId) ?? null
  );
}

export function getWebsiteAccessBySlug(
  access: AdminAccess,
  websiteSlug: string,
): AdminWebsiteAccess | null {
  return (
    getWebsites(access).find((website) => website.slug === websiteSlug) ?? null
  );
}

export function hasWebsiteAccess(
  access: AdminAccess,
  websiteId: string,
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  return getWebsites(access).some((website) => website.id === websiteId);
}

export function hasWebsiteRole(
  access: AdminAccess,
  websiteId: string,
  roleName: string,
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  const website = getWebsiteAccess(access, websiteId);

  if (!website) {
    return false;
  }

  return website.role?.name === roleName;
}

export function hasWebsitePermission(
  access: AdminAccess,
  websiteId: string,
  permission: string,
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  const website = getWebsiteAccess(access, websiteId);

  if (!website) {
    return false;
  }

  const permissions = Array.isArray(website.permissions)
    ? website.permissions
    : [];

  return permissions.includes(permission);
}

export function hasAnyWebsitePermission(
  access: AdminAccess,
  permission: string,
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  return getWebsites(access).some((website) => {
    const permissions = Array.isArray(website.permissions)
      ? website.permissions
      : [];

    return permissions.includes(permission);
  });
}

export function hasAnyGlobalPermission(
  access: AdminAccess,
  permissions: readonly string[],
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  const currentPermissions = getGlobalPermissions(access);

  return permissions.some((permission) =>
    currentPermissions.includes(permission),
  );
}

export function hasAllGlobalPermissions(
  access: AdminAccess,
  permissions: readonly string[],
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  const currentPermissions = getGlobalPermissions(access);

  return permissions.every((permission) =>
    currentPermissions.includes(permission),
  );
}

export function hasAnyWebsitePermissionFromList(
  access: AdminAccess,
  permissions: readonly string[],
): boolean {
  if (isSuperAdmin(access)) {
    return true;
  }

  return getWebsites(access).some((website) => {
    const currentPermissions = Array.isArray(website.permissions)
      ? website.permissions
      : [];

    return permissions.some((permission) =>
      currentPermissions.includes(permission),
    );
  });
}

/*
 * ============================================================
 * COMPATIBILITY HELPERS
 * ============================================================
 */

export function hasPermission(
  access: AdminAccess,
  permission: string,
): boolean {
  return hasGlobalPermission(access, permission);
}

export function hasAnyPermission(
  access: AdminAccess,
  permissions: readonly string[],
): boolean {
  return hasAnyGlobalPermission(access, permissions);
}

export function hasAllPermissions(
  access: AdminAccess,
  permissions: readonly string[],
): boolean {
  return hasAllGlobalPermissions(access, permissions);
}
