import { z } from "zod";

export const membersQuerySchema = z.object({
  q: z.string().trim().max(100).default(""),

  page: z.coerce.number().int().min(1).default(1),

  limit: z.coerce.number().int().min(1).max(100).default(20),

  role: z.string().trim().min(1).optional(),
});

export type MembersQuery = z.infer<typeof membersQuerySchema>;
