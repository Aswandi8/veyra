import { cache } from "react";

import { cookies } from "next/headers";

import { getCentralApiUrl } from "@/lib/auth/proxy";

import type {
  WebsiteDetailResponse,
  WebsiteListItem,
  WebsiteListResponse,
} from "@/lib/websites/types";

import type { WebsitesQuery } from "@/lib/websites/schema";

interface WebsiteApiStatistics {
  users?: number;
  members?: number;
  videos?: number;
  categories?: number;
  views?: number;
  apiClients?: number;
}

interface RawWebsite {
  id: string;

  name: string;
  slug: string;

  description: string | null;
  domain: string | null;

  status: "ACTIVE" | "INACTIVE" | "MAINTENANCE";

  statistics?: WebsiteApiStatistics;

  createdAt: string;
  updatedAt: string;
}

interface RawWebsiteListResponse {
  success: boolean;
  data?: RawWebsite[];
  error?: string;
}

interface RawWebsiteDetailResponse {
  success: boolean;
  data?: RawWebsite;
  error?: string;
}

function normalizeWebsite(website: RawWebsite): WebsiteListItem {
  return {
    id: website.id,

    name: website.name,
    slug: website.slug,

    description: website.description,

    domain: website.domain,

    status: website.status,

    statistics: {
      /*
       * Mendukung response lama `users`
       * maupun response baru `members`.
       */
      members: website.statistics?.members ?? website.statistics?.users ?? 0,

      videos: website.statistics?.videos ?? 0,

      categories: website.statistics?.categories ?? 0,

      views: website.statistics?.views ?? 0,

      apiClients: website.statistics?.apiClients ?? 0,
    },

    createdAt: website.createdAt,

    updatedAt: website.updatedAt,
  };
}

async function getCookieHeader(): Promise<string> {
  const cookieStore = await cookies();

  return cookieStore
    .getAll()
    .map(({ name, value }) => `${name}=${value}`)
    .join("; ");
}

export const getServerWebsites = cache(
  async (
    q: string,
    page: number,
    limit: number,
    status?: WebsitesQuery["status"],
  ) => {
    const cookieHeader = await getCookieHeader();

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/websites`,
      {
        method: "GET",

        headers: {
          Cookie: cookieHeader,

          Accept: "application/json",
        },

        cache: "no-store",
      },
    );

    if (!response.ok) {
      throw new Error(`Unable to load websites (${response.status})`);
    }

    const result = (await response.json()) as RawWebsiteListResponse;

    if (!result.success || !Array.isArray(result.data)) {
      throw new Error(result.error ?? "Invalid website response");
    }

    let websites = result.data.map(normalizeWebsite);

    const normalizedSearch = q.trim().toLowerCase();

    if (normalizedSearch) {
      websites = websites.filter(
        (website) =>
          website.name.toLowerCase().includes(normalizedSearch) ||
          website.slug.toLowerCase().includes(normalizedSearch) ||
          website.domain?.toLowerCase().includes(normalizedSearch),
      );
    }

    if (status) {
      websites = websites.filter((website) => website.status === status);
    }

    const total = websites.length;

    const totalPages = total === 0 ? 0 : Math.ceil(total / limit);

    /*
     * Kalau user sedang berada di page
     * yang sudah melebihi hasil filter,
     * jangan menghasilkan index negatif.
     */
    const safePage = totalPages === 0 ? 1 : Math.min(page, totalPages);

    const start = (safePage - 1) * limit;

    const data = websites.slice(start, start + limit);

    return {
      success: true,
      data,

      pagination: {
        page: safePage,

        limit,

        total,

        totalPages,
      },
    };
  },
);

export const getServerWebsite = cache(
  async (websiteId: string): Promise<WebsiteDetailResponse> => {
    const cookieHeader = await getCookieHeader();

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(
        websiteId,
      )}`,
      {
        method: "GET",

        headers: {
          Cookie: cookieHeader,

          Accept: "application/json",
        },

        cache: "no-store",
      },
    );

    if (response.status === 404) {
      return {
        success: false,
        error: "Website not found",
      };
    }

    if (!response.ok) {
      throw new Error(`Unable to load website (${response.status})`);
    }

    const result = (await response.json()) as RawWebsiteDetailResponse;

    if (!result.success || !result.data) {
      return {
        success: false,

        error: result.error ?? "Website not found",
      };
    }

    return {
      success: true,

      data: normalizeWebsite(result.data),
    };
  },
);
