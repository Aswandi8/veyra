import {
  Activity,
  Edit3,
  KeyRound,
  Tags,
  Users,
  UserPlus,
  Video,
} from "lucide-react";

import Link from "next/link";

import { notFound, redirect } from "next/navigation";

import { StatusBadge } from "@/components/common/status/status-badge";

import { Button } from "@/components/ui/button";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { TypographyH1, TypographyMuted } from "@/components/ui/typography";

import { AUTH_ROUTES } from "@/lib/auth/constants";

import { formatDateTime } from "@/lib/format/date";

import {
  hasGlobalPermission,
  hasWebsitePermission,
} from "@/lib/permissions/access";

import { PERMISSIONS } from "@/lib/permissions/constants";

import { getServerAdminAccess } from "@/lib/permissions/server";

import { getServerWebsite } from "@/lib/websites/server";

interface WebsiteDetailPageProps {
  params: Promise<{
    id: string;
  }>;
}

export default async function WebsiteDetailPage({
  params,
}: WebsiteDetailPageProps) {
  const { id } = await params;

  const access = await getServerAdminAccess();

  if (!access) {
    redirect(AUTH_ROUTES.dashboard);
  }

  /*
   * Website detail management adalah global.
   * SUPER_ADMIN otomatis lolos.
   */
  const canRead = hasGlobalPermission(access, PERMISSIONS.website.read);

  if (!canRead) {
    redirect(AUTH_ROUTES.dashboard);
  }

  const canUpdate = hasGlobalPermission(access, PERMISSIONS.website.update);

  const canReadMembers = hasWebsitePermission(
    access,
    id,
    PERMISSIONS.member.read,
  );

  const response = await getServerWebsite(id);

  if (!response.success || !response.data) {
    notFound();
  }

  const website = response.data;

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <TypographyH1>{website.name}</TypographyH1>

            <StatusBadge status={website.status} />
          </div>

          <TypographyMuted>/{website.slug}</TypographyMuted>
        </div>

        <div className="flex flex-wrap gap-2">
          {canReadMembers && (
            <>
              <Button variant="outline">
                <Link href={`/websites/${id}/members`}>
                  <Users className="size-4" />
                  Members
                </Link>
              </Button>

              <Button variant="outline">
                <Link href={`/websites/${id}/invitations`}>
                  <UserPlus className="size-4" />
                  Invitations
                </Link>
              </Button>
            </>
          )}

          {canUpdate && (
            <Button>
              <Link href={`/websites/${id}/edit`}>
                <Edit3 className="size-4" />
                Edit
              </Link>
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard
          title="Members"
          value={website.statistics.members}
          icon={Users}
        />

        <StatCard
          title="Videos"
          value={website.statistics.videos}
          icon={Video}
        />

        <StatCard
          title="Categories"
          value={website.statistics.categories}
          icon={Tags}
        />

        <StatCard
          title="Views"
          value={website.statistics.views}
          icon={Activity}
        />

        <StatCard
          title="API Clients"
          value={website.statistics.apiClients}
          icon={KeyRound}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Website information</CardTitle>

            <CardDescription>
              Basic website identity and routing information.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-5">
            <Information label="Name" value={website.name} />

            <Information label="Slug" value={website.slug} />

            <Information label="Domain" value={website.domain ?? "—"} />

            <Information label="Status" value={website.status} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Description</CardTitle>

            <CardDescription>
              Additional information about this website.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <p className="whitespace-pre-wrap text-sm leading-6">
              {website.description ?? "No description provided."}
            </p>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Metadata</CardTitle>
          </CardHeader>

          <CardContent className="grid gap-5 sm:grid-cols-2">
            <Information
              label="Created"
              value={formatDateTime(website.createdAt)}
            />

            <Information
              label="Last updated"
              value={formatDateTime(website.updatedAt)}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Information({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-1">
      <TypographyMuted className="text-xs">{label}</TypographyMuted>

      <p className="font-medium">{value}</p>
    </div>
  );
}

function StatCard({
  title,
  value,
  icon: Icon,
}: {
  title: string;
  value: number;
  icon: typeof Users;
}) {
  return (
    <Card>
      <CardContent className="flex items-center justify-between p-5">
        <div>
          <TypographyMuted>{title}</TypographyMuted>

          <p className="mt-1 text-2xl font-semibold tracking-tight">
            {value.toLocaleString()}
          </p>
        </div>

        <div className="flex size-10 items-center justify-center rounded-lg bg-muted">
          <Icon className="size-5 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}
