import { redirect } from "next/navigation";

import { WebsiteForm } from "@/components/websites/website-form";

import { TypographyH1, TypographyMuted } from "@/components/ui/typography";

import { AUTH_ROUTES } from "@/lib/auth/constants";

import { hasGlobalPermission } from "@/lib/permissions/access";

import { PERMISSIONS } from "@/lib/permissions/constants";

import { getServerAdminAccess } from "@/lib/permissions/server";

export default async function NewWebsitePage() {
  const access = await getServerAdminAccess();

  if (!access) {
    redirect(AUTH_ROUTES.dashboard);
  }

  if (!hasGlobalPermission(access, PERMISSIONS.website.create)) {
    redirect(AUTH_ROUTES.dashboard);
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="space-y-1">
        <TypographyH1>New website</TypographyH1>

        <TypographyMuted>Register a new website in Veyra.</TypographyMuted>
      </div>

      <WebsiteForm />
    </div>
  );
}
