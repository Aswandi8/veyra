import { redirect } from "next/navigation";

import { DataTablePagination } from "@/components/common/data-table/data-table-pagination";
import { DataTableProvider } from "@/components/common/data-table/data-table-provider";
import { DataTableToolbar } from "@/components/common/data-table/data-table-toolbar";

import { InvitationsTable } from "@/components/invitations/invitations-table";
import { InviteUserDialog } from "@/components/invitations/invite-user-dialog";

import { TypographyH1, TypographyMuted } from "@/components/ui/typography";

import { AUTH_ROUTES } from "@/lib/auth/constants";

import type { DataTableFilter } from "@/lib/data-table/types";

import { invitationsQuerySchema } from "@/lib/invitations/schema";

import { getServerWebsiteInvitations } from "@/lib/invitations/server";

import { getServerWebsiteRoles } from "@/lib/members/server";

import {
  getWebsiteAccess,
  hasWebsitePermission,
} from "@/lib/permissions/access";

import { PERMISSIONS } from "@/lib/permissions/constants";

import { getServerAdminAccess } from "@/lib/permissions/server";

interface InvitationsPageProps {
  params: Promise<{
    id: string;
  }>;

  searchParams: Promise<{
    q?: string;
    page?: string;
    limit?: string;
    status?: string;
    role?: string;
  }>;
}

export default async function InvitationsPage({
  params,
  searchParams,
}: InvitationsPageProps) {
  const { id: websiteId } = await params;

  const access = await getServerAdminAccess();

  if (!access) {
    redirect(AUTH_ROUTES.dashboard);
  }

  /*
   * User harus mempunyai member.read
   * untuk dapat melihat invitations.
   *
   * SUPER_ADMIN otomatis lolos melalui
   * hasWebsitePermission().
   */
  const canRead = hasWebsitePermission(
    access,
    websiteId,
    PERMISSIONS.member.read,
  );

  if (!canRead) {
    redirect(AUTH_ROUTES.dashboard);
  }

  /*
   * Backend Central API menggunakan
   * member.invite untuk:
   *
   * - membuat invitation
   * - revoke invitation
   *
   * Jadi sementara permission UI mengikuti
   * permission backend yang sama.
   */
  const canInvite = hasWebsitePermission(
    access,
    websiteId,
    PERMISSIONS.member.invite,
  );

  const canRevoke = canInvite;

  /*
   * Untuk user website-scoped, website tersedia
   * dari /admin/me.
   *
   * SUPER_ADMIN tidak membutuhkan assignment,
   * sehingga ini dapat bernilai null.
   */
  const website = getWebsiteAccess(access, websiteId);

  const rawSearchParams = await searchParams;

  const parsed = invitationsQuerySchema.safeParse(rawSearchParams);

  const query = parsed.success ? parsed.data : invitationsQuerySchema.parse({});

  /*
   * Roles tetap dibutuhkan untuk:
   *
   * - filter Role
   * - Invite User dialog
   *
   * Endpoint Central API /websites/:id/roles
   * sudah melakukan role hierarchy filtering.
   */
  const [invitationsResponse, rolesResponse] = await Promise.all([
    getServerWebsiteInvitations(
      websiteId,
      query.q,
      query.page,
      query.limit,
      query.status,
      query.role,
    ),

    getServerWebsiteRoles(websiteId),
  ]);

  const invitations = invitationsResponse.data ?? [];

  const roles = rolesResponse.data ?? [];

  /*
   * =========================================================
   * FILTERS
   * =========================================================
   */

  const roleFilter: DataTableFilter[] =
    roles.length > 0
      ? [
          {
            key: "role",
            label: "Role",

            options: roles.map((role) => ({
              label: role.name.replaceAll("_", " "),

              value: role.id,
            })),
          },
        ]
      : [];

  const filters: readonly DataTableFilter[] = [
    {
      key: "status",
      label: "Status",

      options: [
        {
          label: "Pending",
          value: "PENDING",
        },

        {
          label: "Used",
          value: "USED",
        },

        {
          label: "Expired",
          value: "EXPIRED",
        },

        {
          label: "Revoked",
          value: "REVOKED",
        },
      ],
    },

    ...roleFilter,
  ];

  return (
    <div className="space-y-6">
      {/* ====================================================
          PAGE HEADER
      ==================================================== */}

      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div className="space-y-1">
          <TypographyH1>Invitations</TypographyH1>

          <TypographyMuted>
            Manage pending and historical invitations
            {website ? ` for ${website.name}.` : " for this website."}
          </TypographyMuted>
        </div>

        {canInvite && <InviteUserDialog websiteId={websiteId} roles={roles} />}
      </div>

      {/* ====================================================
          TABLE
      ==================================================== */}

      <DataTableProvider>
        <div className="space-y-6">
          <DataTableToolbar
            searchValue={query.q}
            searchPlaceholder="Search name or email..."
            limit={query.limit}
            total={invitationsResponse.pagination.total}
            itemLabel="invitations"
            filters={filters}
            filterValues={{
              status: query.status,

              role: query.role,
            }}
          />

          <InvitationsTable
            websiteId={websiteId}
            invitations={invitations}
            limit={query.limit}
            canRevoke={canRevoke}
            emptyMessage={
              query.q
                ? "No invitations match your search."
                : "No invitations found."
            }
          />

          <DataTablePagination
            pagination={invitationsResponse.pagination}
            basePath={`/websites/${websiteId}/invitations`}
            query={{
              q: query.q || undefined,

              status: query.status,

              role: query.role,
            }}
            itemLabel="invitations"
          />
        </div>
      </DataTableProvider>
    </div>
  );
}
