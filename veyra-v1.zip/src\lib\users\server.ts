import { cache } from "react";
import { cookies } from "next/headers";

import { getCentralApiUrl } from "@/lib/auth/proxy";
import type { UsersQuery } from "@/lib/users/schema";
import type { UsersResponse } from "@/lib/users/types";

export const getServerUsers = cache(
  async (
    q: string,
    page: number,
    limit: number,
    sort: UsersQuery["sort"],
    order: UsersQuery["order"],
    status?: UsersQuery["status"],
    verified?: UsersQuery["verified"],
    banned?: UsersQuery["banned"],
    role?: UsersQuery["role"],
  ): Promise<UsersResponse> => {
    const cookieStore = await cookies();
    const cookieHeader = cookieStore
      .getAll()
      .map(({ name, value }) => `${name}=${value}`)
      .join("; ");

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
      sort,
      order,
    });

    if (q) params.set("q", q);
    if (status) params.set("status", status);
    if (verified) params.set("verified", verified);
    if (banned) params.set("banned", banned);
    if (role) params.set("role", role);

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/users?${params.toString()}`,
      {
        method: "GET",
        headers: { Cookie: cookieHeader },
        cache: "no-store",
      },
    );

    if (!response.ok) {
      throw new Error(`Unable to load users (${response.status})`);
    }

    return (await response.json()) as UsersResponse;
  },
);
