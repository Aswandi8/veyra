"use client";

import { StatusBadge } from "@/components/common/status/status-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { TypographyMuted } from "@/components/ui/typography";
import type { DataTableColumn } from "@/lib/data-table/types";
import { formatDateTime } from "@/lib/format/date";
import type { UserListItem } from "@/lib/users/types";

function getInitials(name: string): string {
  return (
    name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase())
      .join("") || "U"
  );
}

export const usersColumns: readonly DataTableColumn<UserListItem>[] = [
  {
    id: "user",
    header: "User",
    sortable: true,
    sortKey: "name",
    cell: (user) => (
      <div className="flex items-center gap-3">
        <Avatar>
          {user.image && <AvatarImage src={user.image} alt={user.name} />}
          <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
        </Avatar>

        <div className="min-w-0">
          <div className="truncate font-medium">{user.name}</div>
          <TypographyMuted className="truncate">{user.email}</TypographyMuted>
        </div>
      </div>
    ),
  },
  {
    id: "status",
    header: "Status",
    sortable: true,
    sortKey: "status",
    cell: (user) => (
      <StatusBadge status={user.banned ? "BANNED" : user.status} />
    ),
  },
  {
    id: "roles",
    header: "Roles",
    cell: (user) => (
      <div className="flex flex-wrap gap-1">
        {user.roles.length > 0 ? (
          user.roles.map((role) => (
            <Badge key={role.id} variant="outline">
              {role.name}
            </Badge>
          ))
        ) : (
          <TypographyMuted>No role</TypographyMuted>
        )}
      </div>
    ),
  },
  {
    id: "verification",
    header: "Verification",
    cell: (user) => (
      <StatusBadge status={user.emailVerified ? "VERIFIED" : "UNVERIFIED"} />
    ),
  },
  {
    id: "createdAt",
    header: "Created",
    sortable: true,
    sortKey: "createdAt",
    cell: (user) => (
      <TypographyMuted className="whitespace-nowrap">
        {formatDateTime(user.createdAt)}
      </TypographyMuted>
    ),
  },
];
