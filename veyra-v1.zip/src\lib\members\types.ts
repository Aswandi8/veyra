import type { AuthUserStatus } from "@/lib/auth/types";
import type { PaginationData } from "@/lib/data-table/types";
import type { AdminRole } from "@/lib/permissions/types";

export interface WebsiteMemberUser {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
  image: string | null;
  status: AuthUserStatus;
  banned: boolean;
}

export interface WebsiteMember {
  user: WebsiteMemberUser;
  role: AdminRole;
  assignedAt: string;
  updatedAt: string;
}

export interface WebsiteMembersResponse {
  success: boolean;
  data: WebsiteMember[];
  pagination: PaginationData;
  error?: string;
}

export interface WebsiteRolesResponse {
  success: boolean;
  data: AdminRole[];
  error?: string;
}

export interface MemberMutationResponse {
  success: boolean;
  message?: string;
  error?: string;
}
