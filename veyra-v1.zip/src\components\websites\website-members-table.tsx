"use client";

import { useMemo } from "react";

import { DataTable } from "@/components/common/data-table/data-table";

import { createWebsiteMembersColumns } from "@/components/websites/website-members-columns";

import type { WebsiteMember } from "@/lib/members/types";

import type { AdminRole } from "@/lib/permissions/types";

interface WebsiteMembersTableProps {
  websiteId: string;

  members: WebsiteMember[];

  roles: AdminRole[];

  limit: number;

  canUpdate: boolean;

  canRemove: boolean;

  emptyMessage?: string;
}

export function WebsiteMembersTable({
  websiteId,
  members,
  roles,
  limit,
  canUpdate,
  canRemove,
  emptyMessage = "No members found.",
}: WebsiteMembersTableProps) {
  const columns = useMemo(
    () =>
      createWebsiteMembersColumns({
        websiteId,
        roles,
        canUpdate,
        canRemove,
      }),
    [websiteId, roles, canUpdate, canRemove],
  );

  return (
    <DataTable
      data={members}
      columns={columns}
      getRowKey={(member) => member.user.id}
      emptyMessage={emptyMessage}
      loadingRows={limit}
    />
  );
}
