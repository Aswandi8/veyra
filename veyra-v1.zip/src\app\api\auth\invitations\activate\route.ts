import { NextResponse } from "next/server";

import {
  createProxyHeaders,
  forwardSetCookies,
  getCentralApiUrl,
} from "@/lib/auth/proxy";

export async function POST(request: Request) {
  try {
    const body = await request.text();

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/auth/invitations/activate`,
      {
        method: "POST",

        /*
         * Existing user memerlukan Better Auth session
         * agar Central API dapat memastikan invitation
         * benar-benar diterima pemilik email.
         */
        headers: createProxyHeaders(request, {
          includeCookie: true,
        }),

        body,

        cache: "no-store",
      },
    );

    const result = new NextResponse(response.body, {
      status: response.status,
    });

    const contentType = response.headers.get("content-type");

    if (contentType) {
      result.headers.set("Content-Type", contentType);
    }

    result.headers.set("Cache-Control", "private, no-store, max-age=0");

    forwardSetCookies(response, result.headers);

    return result;
  } catch (error) {
    console.error("[INVITATION ACTIVATE PROXY]", error);

    return NextResponse.json(
      {
        success: false,
        error: "Invitation service is unavailable",
      },
      {
        status: 503,
      },
    );
  }
}
