"use client";

import { useEffect, useMemo, useState, useSyncExternalStore } from "react";

import { useRouter } from "next/navigation";

import { Globe2, ShieldCheck } from "lucide-react";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { Skeleton } from "@/components/ui/skeleton";

import type { AdminAccess, AdminWebsiteAccess } from "@/lib/permissions/types";

import {
  getStoredActiveWebsiteId,
  resolveActiveWebsite,
  setStoredActiveWebsiteId,
  subscribeActiveWebsiteChange,
} from "@/lib/websites/active-website";

import type { ActiveWebsite, WebsiteListResponse } from "@/lib/websites/types";

interface WebsiteSelectorProps {
  access: AdminAccess;
}

function mapAdminWebsite(website: AdminWebsiteAccess): ActiveWebsite {
  return {
    id: website.id,
    name: website.name,
    slug: website.slug,
    status: website.status,
    role: website.role,
    permissions: Array.isArray(website.permissions) ? website.permissions : [],
  };
}

function subscribe(callback: () => void): () => void {
  return subscribeActiveWebsiteChange(() => {
    callback();
  });
}

function getSnapshot(): string | null {
  return getStoredActiveWebsiteId();
}

function getServerSnapshot(): string | null {
  return null;
}

export function WebsiteSelector({ access }: WebsiteSelectorProps) {
  const router = useRouter();

  /*
   * =========================================================
   * USER-SCOPED WEBSITES
   * =========================================================
   *
   * Derived langsung dari /admin/me.
   * Tidak perlu disalin ke state.
   */
  const userWebsites = useMemo(
    () =>
      Array.isArray(access.websites)
        ? access.websites.map(mapAdminWebsite)
        : [],
    [access.websites],
  );

  /*
   * =========================================================
   * SUPER ADMIN WEBSITES
   * =========================================================
   *
   * SUPER_ADMIN tidak mempunyai UserWebsiteRole,
   * jadi seluruh website perlu diambil dari endpoint
   * /api/admin/websites.
   *
   * null = belum selesai fetch
   * []   = fetch selesai tetapi tidak ada website
   */
  const [superAdminWebsites, setSuperAdminWebsites] = useState<
    ActiveWebsite[] | null
  >(null);

  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    if (!access.superAdmin) {
      return;
    }

    const controller = new AbortController();

    async function loadWebsites() {
      try {
        const response = await fetch("/api/admin/websites", {
          method: "GET",
          cache: "no-store",
          signal: controller.signal,

          headers: {
            Accept: "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to load websites");
        }

        const result = (await response.json()) as WebsiteListResponse;

        if (!result.success || !Array.isArray(result.data)) {
          throw new Error(result.error ?? "Invalid website response");
        }

        if (controller.signal.aborted) {
          return;
        }

        setSuperAdminWebsites(
          result.data.map((website) => ({
            id: website.id,
            name: website.name,
            slug: website.slug,
            status: website.status,

            /*
             * SUPER_ADMIN tidak membutuhkan
             * website-specific assignment.
             */
            role: null,

            /*
             * Permission SUPER_ADMIN diperlakukan
             * sebagai bypass oleh Central API.
             */
            permissions: [],
          })),
        );
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }

        if (controller.signal.aborted) {
          return;
        }

        console.error("[WEBSITE SELECTOR]", error);

        setLoadError(true);
      }
    }

    void loadWebsites();

    return () => {
      controller.abort();
    };
  }, [access.superAdmin]);

  /*
   * =========================================================
   * FINAL WEBSITE LIST
   * =========================================================
   *
   * useMemo digunakan supaya referensi array stabil.
   * Ini menghilangkan warning exhaustive-deps.
   */
  const websites = useMemo(() => {
    if (access.superAdmin) {
      return superAdminWebsites ?? [];
    }

    return userWebsites;
  }, [access.superAdmin, superAdminWebsites, userWebsites]);

  const loading =
    access.superAdmin && superAdminWebsites === null && !loadError;

  /*
   * =========================================================
   * ACTIVE WEBSITE COOKIE
   * =========================================================
   *
   * Cookie adalah external store.
   *
   * Jadi gunakan useSyncExternalStore,
   * bukan menyalin cookie ke state lewat useEffect.
   */
  const preferredWebsiteId = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot,
  );

  /*
   * Website aktif sepenuhnya derived dari:
   *
   * websites + preferredWebsiteId
   */
  const activeWebsite = useMemo(
    () => resolveActiveWebsite(websites, preferredWebsiteId),
    [websites, preferredWebsiteId],
  );

  const selectedId = activeWebsite?.id ?? null;

  /*
   * Jika:
   *
   * - cookie belum ada
   * - website yang tersimpan sudah tidak accessible
   * - website sebelumnya sudah dihapus
   *
   * resolveActiveWebsite() akan memilih fallback.
   *
   * Effect ini hanya menyinkronkan hasil React
   * ke external system (document.cookie).
   */
  useEffect(() => {
    if (!activeWebsite) {
      return;
    }

    if (preferredWebsiteId === activeWebsite.id) {
      return;
    }

    setStoredActiveWebsiteId(activeWebsite.id);
  }, [activeWebsite, preferredWebsiteId]);

  const items = useMemo(
    () =>
      websites.map((website) => ({
        value: website.id,
        label: website.name,
      })),
    [websites],
  );

  function handleWebsiteChange(value: string | null) {
    if (!value) {
      return;
    }

    if (value === selectedId) {
      return;
    }

    const website = websites.find((item) => item.id === value);

    if (!website) {
      return;
    }

    setStoredActiveWebsiteId(website.id);

    /*
     * Tidak melakukan:
     *
     * window.location.reload()
     *
     * router.refresh() hanya meminta ulang
     * Server Components dengan cookie baru.
     */
    router.refresh();
  }

  if (loading) {
    return <Skeleton className="h-9 w-44 rounded-lg sm:w-56" />;
  }

  if (loadError) {
    return (
      <div className="hidden h-9 items-center gap-2 rounded-lg border px-3 text-sm text-destructive sm:flex">
        <Globe2 className="size-4" />
        Failed to load websites
      </div>
    );
  }

  if (websites.length === 0) {
    return (
      <div className="hidden h-9 items-center gap-2 rounded-lg border px-3 text-sm text-muted-foreground sm:flex">
        <Globe2 className="size-4" />
        No website access
      </div>
    );
  }

  return (
    <Select
      items={items}
      value={selectedId}
      onValueChange={handleWebsiteChange}
    >
      <SelectTrigger
        className="w-44 min-w-0 sm:w-56"
        aria-label="Select active website"
      >
        <Globe2 className="size-4 text-muted-foreground" />

        <SelectValue />
      </SelectTrigger>

      <SelectContent>
        {websites.map((website) => (
          <SelectItem key={website.id} value={website.id}>
            <div className="flex min-w-0 flex-1 items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate font-medium">{website.name}</div>

                <div className="truncate text-xs text-muted-foreground">
                  {website.slug}
                </div>
              </div>

              {website.role && (
                <div className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                  <ShieldCheck className="size-3" />

                  {website.role.name.replaceAll("_", " ")}
                </div>
              )}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
