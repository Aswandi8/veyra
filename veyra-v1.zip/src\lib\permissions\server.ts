import { cache } from "react";

import { cookies } from "next/headers";

import { redirect } from "next/navigation";

import { getCentralApiUrl } from "@/lib/auth/proxy";
import { AUTH_ROUTES } from "@/lib/auth/constants";

import type { AdminAccess, AdminAccessResponse } from "@/lib/permissions/types";

export const getServerAdminAccess = cache(
  async (): Promise<AdminAccess | null> => {
    const cookieStore = await cookies();

    const cookieHeader = cookieStore
      .getAll()
      .map(({ name, value }) => `${name}=${value}`)
      .join("; ");

    if (!cookieHeader) {
      return null;
    }

    let response: Response;

    try {
      response = await fetch(`${getCentralApiUrl()}/api/v1/admin/me`, {
        method: "GET",

        headers: {
          Cookie: cookieHeader,

          Accept: "application/json",
        },

        cache: "no-store",
      });
    } catch (error) {
      console.error("[GET SERVER ADMIN ACCESS] Connection error:", error);

      throw new Error("Central API unavailable");
    }

    /*
     * Tidak authenticated.
     */
    if (response.status === 401) {
      return null;
    }

    /*
     * Authenticated tetapi bukan admin /
     * tidak mempunyai akses yang diperlukan.
     */
    if (response.status === 403) {
      redirect(AUTH_ROUTES.forbidden);
    }

    /*
     * Backend/server error.
     */
    if (!response.ok) {
      console.error(
        "[GET SERVER ADMIN ACCESS] Central API returned:",
        response.status,
      );

      throw new Error(`Unable to load admin access (${response.status})`);
    }

    let data: AdminAccessResponse;

    try {
      data = (await response.json()) as AdminAccessResponse;
    } catch (error) {
      console.error("[GET SERVER ADMIN ACCESS] Invalid JSON:", error);

      throw new Error("Invalid admin access response");
    }

    if (!data.success || !data.user) {
      throw new Error("Invalid admin access response");
    }

    const globalRoles = Array.isArray(data.globalRoles) ? data.globalRoles : [];

    const globalPermissions = Array.isArray(data.globalPermissions)
      ? data.globalPermissions
      : [];

    const websites = Array.isArray(data.websites)
      ? data.websites.map((website) => ({
          ...website,

          permissions: Array.isArray(website.permissions)
            ? website.permissions
            : [],
        }))
      : [];

    return {
      user: {
        ...data.user,

        banned: data.user.banned ?? false,
      },

      superAdmin: data.superAdmin === true,

      globalRoles,

      globalPermissions,

      websites,
    };
  },
);
