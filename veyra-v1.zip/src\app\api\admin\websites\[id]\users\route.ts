import { NextResponse } from "next/server";

import {
  createProxyHeaders,
  forwardSetCookies,
  getCentralApiUrl,
} from "@/lib/auth/proxy";

interface RouteContext {
  params: Promise<{
    id: string;
  }>;
}

async function proxy(request: Request, context: RouteContext) {
  try {
    const { id } = await context.params;

    const sourceUrl = new URL(request.url);

    const targetUrl = `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(
      id,
    )}/users${sourceUrl.search}`;

    const body = request.method === "GET" ? undefined : request.body;

    const response = await fetch(targetUrl, {
      method: request.method,

      headers: createProxyHeaders(request, {
        includeCookie: true,
      }),

      body,

      cache: "no-store",

      ...(body
        ? {
            duplex: "half" as const,
          }
        : {}),
    });

    const result = new NextResponse(response.body, {
      status: response.status,
    });

    const contentType = response.headers.get("content-type");

    if (contentType) {
      result.headers.set("Content-Type", contentType);
    }

    result.headers.set("Cache-Control", "private, no-store, max-age=0");

    forwardSetCookies(response, result.headers);

    return result;
  } catch (error) {
    console.error("[WEBSITE MEMBERS PROXY]", error);

    return NextResponse.json(
      {
        success: false,
        error: "Central API unavailable",
      },
      {
        status: 503,
      },
    );
  }
}

export async function GET(request: Request, context: RouteContext) {
  return proxy(request, context);
}

export async function POST(request: Request, context: RouteContext) {
  return proxy(request, context);
}

export async function PUT(request: Request, context: RouteContext) {
  return proxy(request, context);
}

export async function DELETE(request: Request, context: RouteContext) {
  return proxy(request, context);
}
