export function createDataTableHref(
  pathname: string,
  currentQuery: Record<string, string | number | undefined>,
  updates: Record<string, string | number | null | undefined>,
): string {
  const params = new URLSearchParams();

  for (const [key, value] of Object.entries(currentQuery)) {
    if (value !== undefined && value !== "") {
      params.set(key, String(value));
    }
  }

  for (const [key, value] of Object.entries(updates)) {
    if (value === null || value === undefined || value === "") {
      params.delete(key);
    } else {
      params.set(key, String(value));
    }
  }

  const query = params.toString();

  return query ? `${pathname}?${query}` : pathname;
}
