"use client";

import * as React from "react";

import { zodResolver } from "@hookform/resolvers/zod";

import { Loader2, Save } from "lucide-react";

import { useRouter } from "next/navigation";

import { useForm } from "react-hook-form";

import toast from "react-hot-toast";

import { Button } from "@/components/ui/button";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { Textarea } from "@/components/ui/textarea";

import {
  websiteFormSchema,
  type WebsiteFormValues,
} from "@/lib/websites/schema";

import type {
  WebsiteListItem,
  WebsiteMutationResponse,
} from "@/lib/websites/types";

interface WebsiteFormProps {
  website?: WebsiteListItem;
}

const statusItems = [
  {
    value: "ACTIVE",
    label: "Active",
  },

  {
    value: "INACTIVE",
    label: "Inactive",
  },

  {
    value: "MAINTENANCE",
    label: "Maintenance",
  },
] as const;

function normalizeSlug(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function WebsiteForm({ website }: WebsiteFormProps) {
  const router = useRouter();

  const editing = Boolean(website);

  const [slugTouched, setSlugTouched] = React.useState(editing);

  const {
    register,
    handleSubmit,
    watch,
    setValue,

    formState: { errors, isSubmitting },
  } = useForm<WebsiteFormValues>({
    resolver: zodResolver(websiteFormSchema),

    defaultValues: {
      name: website?.name ?? "",

      slug: website?.slug ?? "",

      description: website?.description ?? "",

      domain: website?.domain ?? "",

      status: website?.status ?? "ACTIVE",
    },
  });

  const name = watch("name");

  const status = watch("status");

  React.useEffect(() => {
    if (editing || slugTouched) {
      return;
    }

    setValue("slug", normalizeSlug(name), {
      shouldValidate: false,
    });
  }, [editing, name, setValue, slugTouched]);

  async function onSubmit(values: WebsiteFormValues) {
    const payload = {
      name: values.name.trim(),

      slug: values.slug.trim().toLowerCase(),

      description: values.description?.trim() || null,

      domain: values.domain?.trim().toLowerCase() || null,

      status: values.status,
    };

    try {
      const endpoint =
        editing && website
          ? `/api/admin/websites/${encodeURIComponent(website.id)}`
          : "/api/admin/websites";

      const response = await fetch(endpoint, {
        method: editing ? "PUT" : "POST",

        headers: {
          "Content-Type": "application/json",
        },

        credentials: "include",

        cache: "no-store",

        body: JSON.stringify(payload),
      });

      const contentType = response.headers.get("content-type") ?? "";

      if (!contentType.includes("application/json")) {
        toast.error("Server returned an invalid response.");

        return;
      }

      const result = (await response.json()) as WebsiteMutationResponse;

      if (!response.ok || !result.success) {
        toast.error(result.error ?? "Unable to save website.");

        return;
      }

      toast.success(
        editing
          ? "Website updated successfully."
          : "Website created successfully.",
      );

      const websiteId = result.data?.id ?? website?.id;

      if (websiteId) {
        router.replace(`/websites/${websiteId}`);
      } else {
        router.replace("/websites");
      }

      router.refresh();
    } catch (error) {
      console.error("[WEBSITE FORM]", error);

      toast.error("Central API is unavailable.");
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{editing ? "Edit website" : "Create website"}</CardTitle>

        <CardDescription>
          {editing
            ? "Update website identity, domain, and operational status."
            : "Create a new website managed by Veyra."}
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form
          id="website-form"
          onSubmit={handleSubmit(onSubmit)}
          noValidate
          className="space-y-6"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Website name</Label>

              <Input
                id="name"
                disabled={isSubmitting}
                placeholder="Veyra Media"
                aria-invalid={Boolean(errors.name)}
                {...register("name")}
              />

              {errors.name?.message && (
                <p className="text-sm text-destructive">
                  {errors.name.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="slug">Slug</Label>

              <Input
                id="slug"
                disabled={isSubmitting}
                placeholder="veyra-media"
                aria-invalid={Boolean(errors.slug)}
                {...register("slug", {
                  onChange: () => setSlugTouched(true),
                })}
              />

              {errors.slug?.message && (
                <p className="text-sm text-destructive">
                  {errors.slug.message}
                </p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="domain">Domain</Label>

            <Input
              id="domain"
              disabled={isSubmitting}
              placeholder="example.com"
              aria-invalid={Boolean(errors.domain)}
              {...register("domain")}
            />

            {errors.domain?.message && (
              <p className="text-sm text-destructive">
                {errors.domain.message}
              </p>
            )}

            <p className="text-xs text-muted-foreground">
              Use the hostname only, without http:// or https://.
            </p>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>

            <Select
              items={statusItems}
              value={status}
              onValueChange={(value) => {
                if (!value) {
                  return;
                }

                setValue("status", value, {
                  shouldDirty: true,

                  shouldValidate: true,
                });
              }}
              disabled={isSubmitting}
            >
              <SelectTrigger className="w-full sm:w-64">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>

              <SelectContent>
                <SelectItem value="ACTIVE">Active</SelectItem>

                <SelectItem value="INACTIVE">Inactive</SelectItem>

                <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>

            <Textarea
              id="description"
              disabled={isSubmitting}
              rows={5}
              placeholder="Optional description..."
              aria-invalid={Boolean(errors.description)}
              {...register("description")}
            />

            {errors.description?.message && (
              <p className="text-sm text-destructive">
                {errors.description.message}
              </p>
            )}
          </div>
        </form>
      </CardContent>

      <CardFooter className="justify-between gap-3">
        <Button
          type="button"
          variant="outline"
          disabled={isSubmitting}
          onClick={() => router.back()}
        >
          Cancel
        </Button>

        <Button type="submit" form="website-form" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="size-4" />

              {editing ? "Save changes" : "Create website"}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
