import { NextResponse } from "next/server";

import {
  createProxyHeaders,
  forwardSetCookies,
  getCentralApiUrl,
} from "@/lib/auth/proxy";

interface RouteContext {
  params: Promise<{
    id: string;
  }>;
}

function createResponse(response: Response) {
  const result = new NextResponse(response.body, {
    status: response.status,
  });

  const contentType = response.headers.get("content-type");

  if (contentType) {
    result.headers.set("Content-Type", contentType);
  }

  result.headers.set("Cache-Control", "private, no-store, max-age=0");

  forwardSetCookies(response, result.headers);

  return result;
}

async function proxy(request: Request, context: RouteContext) {
  const { id } = await context.params;

  const method = request.method;

  const hasBody = method === "POST" || method === "PUT" || method === "PATCH";

  const body = hasBody ? await request.text() : undefined;

  const response = await fetch(
    `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(id)}`,
    {
      method,

      headers: createProxyHeaders(request, {
        includeCookie: true,
      }),

      body,

      cache: "no-store",
    },
  );

  return createResponse(response);
}

export async function GET(request: Request, context: RouteContext) {
  try {
    return await proxy(request, context);
  } catch (error) {
    console.error("[WEBSITE GET PROXY]", error);

    return NextResponse.json(
      {
        success: false,

        error: "Central API unavailable",
      },
      {
        status: 503,
      },
    );
  }
}

export async function PUT(request: Request, context: RouteContext) {
  try {
    return await proxy(request, context);
  } catch (error) {
    console.error("[WEBSITE PUT PROXY]", error);

    return NextResponse.json(
      {
        success: false,

        error: "Central API unavailable",
      },
      {
        status: 503,
      },
    );
  }
}

export async function DELETE(request: Request, context: RouteContext) {
  try {
    return await proxy(request, context);
  } catch (error) {
    console.error("[WEBSITE DELETE PROXY]", error);

    return NextResponse.json(
      {
        success: false,

        error: "Central API unavailable",
      },
      {
        status: 503,
      },
    );
  }
}
