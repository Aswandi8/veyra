import type { AuthUserStatus } from "@/lib/auth/types";
import type { PaginationData } from "@/lib/data-table/types";

export interface UserRole {
  id: string;
  name: string;
  description: string | null;
}

export interface UserListItem {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
  image: string | null;
  status: AuthUserStatus;
  role: string | null;
  banned: boolean;
  banReason: string | null;
  banExpires: string | null;
  createdAt: string;
  updatedAt: string;
  roles: UserRole[];
}

export interface UsersResponse {
  success: boolean;
  data: UserListItem[];
  pagination: PaginationData;
}

export interface UserMutationResponse {
  success: boolean;
  message?: string;
  error?: string;
  data?: {
    count?: number;
    status?: string;
  };
}
