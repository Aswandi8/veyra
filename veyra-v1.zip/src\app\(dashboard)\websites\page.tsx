import { Plus } from "lucide-react";

import Link from "next/link";

import { DataTablePagination } from "@/components/common/data-table/data-table-pagination";
import { DataTableProvider } from "@/components/common/data-table/data-table-provider";
import { DataTableToolbar } from "@/components/common/data-table/data-table-toolbar";

import { WebsitesTable } from "@/components/websites/websites-table";

import { Button } from "@/components/ui/button";

import { TypographyH1, TypographyMuted } from "@/components/ui/typography";

import type { DataTableFilter } from "@/lib/data-table/types";

import { hasGlobalPermission } from "@/lib/permissions/access";

import { PERMISSIONS } from "@/lib/permissions/constants";

import {
  requireAdminAccess,
  requireGlobalPermission,
} from "@/lib/permissions/guards";

import { websitesQuerySchema } from "@/lib/websites/schema";

import { getServerWebsites } from "@/lib/websites/server";

interface WebsitesPageProps {
  searchParams: Promise<{
    q?: string;
    page?: string;
    limit?: string;
    status?: string;
  }>;
}

export default async function WebsitesPage({
  searchParams,
}: WebsitesPageProps) {
  /* =========================================================
     ACCESS
     ========================================================= */

  const access = await requireAdminAccess();

  requireGlobalPermission(access, PERMISSIONS.website.read);

  const canCreate = hasGlobalPermission(access, PERMISSIONS.website.create);

  const canUpdate = hasGlobalPermission(access, PERMISSIONS.website.update);

  const canDelete = hasGlobalPermission(access, PERMISSIONS.website.delete);

  /* =========================================================
     QUERY
     ========================================================= */

  const raw = await searchParams;

  const parsed = websitesQuerySchema.safeParse(raw);

  const query = parsed.success ? parsed.data : websitesQuerySchema.parse({});

  /* =========================================================
     DATA
     ========================================================= */

  const websites = await getServerWebsites(
    query.q,
    query.page,
    query.limit,
    query.status,
  );

  /* =========================================================
     FILTERS
     ========================================================= */

  const filters: readonly DataTableFilter[] = [
    {
      key: "status",

      label: "Status",

      options: [
        {
          label: "Active",
          value: "ACTIVE",
        },

        {
          label: "Inactive",
          value: "INACTIVE",
        },

        {
          label: "Maintenance",
          value: "MAINTENANCE",
        },
      ],
    },
  ];

  /* =========================================================
     ACTIONS
     ========================================================= */

  const createAction = canCreate ? (
    <Button size="sm">
      <Link href="/websites/new">
        <Plus className="size-4" />
        New website
      </Link>
    </Button>
  ) : null;

  /* =========================================================
     RENDER
     ========================================================= */

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <TypographyH1>Websites</TypographyH1>

        <TypographyMuted>Manage websites connected to Veyra.</TypographyMuted>
      </div>

      <DataTableProvider>
        <div className="space-y-6">
          <DataTableToolbar
            searchValue={query.q}
            searchPlaceholder="Search website, slug, or domain..."
            limit={query.limit}
            total={websites.pagination.total}
            itemLabel="websites"
            filters={filters}
            filterValues={{
              status: query.status,
            }}
            actions={createAction}
          />

          <WebsitesTable
            websites={websites.data}
            limit={query.limit}
            canUpdate={canUpdate}
            canDelete={canDelete}
            emptyMessage={
              query.q ? "No websites match your search." : "No websites found."
            }
          />

          <DataTablePagination
            pagination={websites.pagination}
            basePath="/websites"
            query={{
              q: query.q || undefined,

              status: query.status,
            }}
            itemLabel="websites"
          />
        </div>
      </DataTableProvider>
    </div>
  );
}
