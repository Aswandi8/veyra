"use client";

import { useMemo } from "react";

import { DataTable } from "@/components/common/data-table/data-table";

import { createWebsitesColumns } from "@/components/websites/websites-columns";

import type { WebsiteListItem } from "@/lib/websites/types";

interface WebsitesTableProps {
  websites: WebsiteListItem[];

  limit: number;

  canUpdate: boolean;
  canDelete: boolean;

  emptyMessage?: string;
}

export function WebsitesTable({
  websites,
  limit,
  canUpdate,
  canDelete,
  emptyMessage = "No websites found.",
}: WebsitesTableProps) {
  const columns = useMemo(
    () =>
      createWebsitesColumns({
        canUpdate,
        canDelete,
      }),
    [canUpdate, canDelete],
  );

  return (
    <DataTable
      data={websites}
      columns={columns}
      getRowKey={(website) => website.id}
      loadingRows={limit}
      emptyMessage={emptyMessage}
    />
  );
}
