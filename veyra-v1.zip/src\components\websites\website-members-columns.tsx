"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import { Badge } from "@/components/ui/badge";

import { StatusBadge } from "@/components/common/status/status-badge";

import { TypographyMuted } from "@/components/ui/typography";

import { WebsiteMemberActions } from "@/components/websites/website-member-actions";

import type { DataTableColumn } from "@/lib/data-table/types";

import { formatDateTime } from "@/lib/format/date";

import type { WebsiteMember } from "@/lib/members/types";

import type { AdminRole } from "@/lib/permissions/types";

interface CreateWebsiteMembersColumnsOptions {
  websiteId: string;

  roles: AdminRole[];

  canUpdate: boolean;

  canRemove: boolean;
}

function getInitials(name: string): string {
  return (
    name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase())
      .join("") || "U"
  );
}

export function createWebsiteMembersColumns({
  websiteId,
  roles,
  canUpdate,
  canRemove,
}: CreateWebsiteMembersColumnsOptions): readonly DataTableColumn<WebsiteMember>[] {
  const columns: DataTableColumn<WebsiteMember>[] = [
    {
      id: "user",
      header: "Member",

      cell: (member) => (
        <div className="flex items-center gap-3">
          <Avatar>
            {member.user.image && (
              <AvatarImage src={member.user.image} alt={member.user.name} />
            )}

            <AvatarFallback>{getInitials(member.user.name)}</AvatarFallback>
          </Avatar>

          <div className="min-w-0">
            <div className="truncate font-medium">{member.user.name}</div>

            <TypographyMuted className="truncate">
              {member.user.email}
            </TypographyMuted>
          </div>
        </div>
      ),
    },

    {
      id: "role",
      header: "Role",

      cell: (member) => (
        <Badge variant="outline">{member.role.name.replaceAll("_", " ")}</Badge>
      ),
    },

    {
      id: "status",
      header: "Status",

      cell: (member) => (
        <StatusBadge
          status={member.user.banned ? "BANNED" : member.user.status}
        />
      ),
    },

    {
      id: "verification",
      header: "Verification",

      cell: (member) => (
        <StatusBadge
          status={member.user.emailVerified ? "VERIFIED" : "UNVERIFIED"}
        />
      ),
    },

    {
      id: "assignedAt",
      header: "Assigned",

      cell: (member) => (
        <TypographyMuted className="whitespace-nowrap">
          {formatDateTime(member.assignedAt)}
        </TypographyMuted>
      ),
    },
  ];

  if (canUpdate || canRemove) {
    columns.push({
      id: "actions",

      header: <span className="sr-only">Actions</span>,

      headerClassName: "w-12 text-right",

      cellClassName: "w-12 text-right",

      cell: (member) => (
        <WebsiteMemberActions
          websiteId={websiteId}
          member={member}
          roles={roles}
          canUpdate={canUpdate}
          canRemove={canRemove}
        />
      ),
    });
  }

  return columns;
}
