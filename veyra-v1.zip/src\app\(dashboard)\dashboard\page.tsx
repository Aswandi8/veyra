import {
  TypographyH1,
  TypographyMuted,
  TypographyP,
} from "@/components/ui/typography";

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <TypographyH1>Dashboard</TypographyH1>
        <TypographyMuted>
          Welcome to Veyra Central Management System.
        </TypographyMuted>
      </div>

      <div className="rounded-xl border bg-card p-6 shadow-sm">
        <TypographyP>Dashboard Veyra siap digunakan.</TypographyP>
      </div>
    </div>
  );
}
