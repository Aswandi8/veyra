import type { ComponentProps } from "react";

import type { Badge } from "@/components/ui/badge";

type BadgeVariant = ComponentProps<typeof Badge>["variant"];

export interface StatusConfig {
  label: string;
  variant: BadgeVariant;
}

const STATUS_CONFIG: Record<string, StatusConfig> = {
  ACTIVE: { label: "Active", variant: "default" },
  INACTIVE: { label: "Inactive", variant: "secondary" },
  SUSPENDED: { label: "Suspended", variant: "outline" },
  BANNED: { label: "Banned", variant: "destructive" },

  DRAFT: { label: "Draft", variant: "secondary" },
  PROCESSING: { label: "Processing", variant: "outline" },
  READY: { label: "Ready", variant: "default" },
  PUBLISHED: { label: "Published", variant: "default" },
  ARCHIVED: { label: "Archived", variant: "secondary" },

  PUBLIC: { label: "Public", variant: "default" },
  PRIVATE: { label: "Private", variant: "secondary" },
  UNLISTED: { label: "Unlisted", variant: "outline" },

  MAINTENANCE: { label: "Maintenance", variant: "outline" },
  REVOKED: { label: "Revoked", variant: "destructive" },

  VERIFIED: { label: "Verified", variant: "default" },
  UNVERIFIED: { label: "Unverified", variant: "secondary" },

  ENABLED: { label: "Enabled", variant: "default" },
  DISABLED: { label: "Disabled", variant: "secondary" },

  PENDING: { label: "Pending", variant: "outline" },
  USED: { label: "Used", variant: "default" },
  EXPIRED: { label: "Expired", variant: "secondary" },
};

function formatStatus(status: string): string {
  return status
    .toLowerCase()
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function getStatusConfig(status: string): StatusConfig {
  const normalized = status.trim().toUpperCase();

  return (
    STATUS_CONFIG[normalized] ?? {
      label: formatStatus(normalized),
      variant: "outline",
    }
  );
}
