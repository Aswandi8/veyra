"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useTransition,
  type ReactNode,
} from "react";
import { usePathname, useRouter } from "next/navigation";

interface DataTableNavigationContextValue {
  isPending: boolean;
  navigate: (href: string) => void;
  refresh: () => void;
  updateQuery: (
    updates: Record<string, string | number | null | undefined>,
  ) => void;
}

const DataTableNavigationContext =
  createContext<DataTableNavigationContextValue | null>(null);

interface DataTableProviderProps {
  children: ReactNode;
}

export function DataTableProvider({ children }: DataTableProviderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();

  const navigate = useCallback(
    (href: string) => {
      startTransition(() => router.replace(href, { scroll: false }));
    },
    [router],
  );

  const refresh = useCallback(() => {
    startTransition(() => router.refresh());
  }, [router]);

  const updateQuery = useCallback(
    (updates: Record<string, string | number | null | undefined>) => {
      const params = new URLSearchParams(window.location.search);

      for (const [key, value] of Object.entries(updates)) {
        if (value === null || value === undefined || value === "")
          params.delete(key);
        else params.set(key, String(value));
      }

      const query = params.toString();

      navigate(query ? `${pathname}?${query}` : pathname);
    },
    [navigate, pathname],
  );

  const value = useMemo(
    () => ({ isPending, navigate, refresh, updateQuery }),
    [isPending, navigate, refresh, updateQuery],
  );

  return (
    <DataTableNavigationContext.Provider value={value}>
      {children}
    </DataTableNavigationContext.Provider>
  );
}

export function useDataTableNavigation() {
  const context = useContext(DataTableNavigationContext);

  if (!context) {
    throw new Error(
      "useDataTableNavigation must be used inside DataTableProvider",
    );
  }

  return context;
}
