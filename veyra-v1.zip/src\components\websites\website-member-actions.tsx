"use client";

import { useState } from "react";

import { MoreHorizontal, ShieldCheck, Trash2 } from "lucide-react";

import { useRouter } from "next/navigation";

import { ConfirmDialog } from "@/components/common/dialog/confirm-dialog";

import { Button } from "@/components/ui/button";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { Label } from "@/components/ui/label";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import type { WebsiteMember } from "@/lib/members/types";

import type { AdminRole } from "@/lib/permissions/types";

interface WebsiteMemberActionsProps {
  websiteId: string;

  member: WebsiteMember;

  roles: AdminRole[];

  canUpdate: boolean;

  canRemove: boolean;
}

interface MutationResponse {
  success: boolean;
  message?: string;
  error?: string;
}

export function WebsiteMemberActions({
  websiteId,
  member,
  roles,
  canUpdate,
  canRemove,
}: WebsiteMemberActionsProps) {
  const router = useRouter();

  const [roleDialogOpen, setRoleDialogOpen] = useState(false);

  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);

  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(
    member.role.id,
  );

  const [loading, setLoading] = useState(false);

  const [error, setError] = useState<string | null>(null);

  const roleItems = roles.map((role) => ({
    value: role.id,

    label: role.name.replaceAll("_", " "),
  }));

  async function updateRole() {
    if (!selectedRoleId) {
      setError("Role is required.");

      return;
    }

    if (selectedRoleId === member.role.id) {
      setRoleDialogOpen(false);

      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/admin/websites/${encodeURIComponent(websiteId)}/users`,
        {
          method: "PUT",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            userId: member.user.id,

            roleId: selectedRoleId,
          }),
        },
      );

      const result = (await response.json()) as MutationResponse;

      if (!response.ok || !result.success) {
        setError(result.error ?? "Unable to update member role.");

        return;
      }

      setRoleDialogOpen(false);

      router.refresh();
    } catch {
      setError("Central API is unavailable.");
    } finally {
      setLoading(false);
    }
  }

  async function removeMember() {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/admin/websites/${encodeURIComponent(websiteId)}/users`,
        {
          method: "DELETE",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            userId: member.user.id,
          }),
        },
      );

      const result = (await response.json()) as MutationResponse;

      if (!response.ok || !result.success) {
        setError(result.error ?? "Unable to remove member.");

        setRemoveDialogOpen(false);

        return;
      }

      setRemoveDialogOpen(false);

      router.refresh();
    } catch {
      setError("Central API is unavailable.");

      setRemoveDialogOpen(false);
    } finally {
      setLoading(false);
    }
  }

  if (!canUpdate && !canRemove) {
    return null;
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          render={
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label={`Actions for ${member.user.name}`}
            />
          }
        >
          <MoreHorizontal className="size-4" />
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end" className="min-w-44">
          {canUpdate && (
            <DropdownMenuItem
              onClick={() => {
                setError(null);

                setSelectedRoleId(member.role.id);

                setRoleDialogOpen(true);
              }}
            >
              <ShieldCheck />
              Change role
            </DropdownMenuItem>
          )}

          {canUpdate && canRemove && <DropdownMenuSeparator />}

          {canRemove && (
            <DropdownMenuItem
              variant="destructive"
              onClick={() => {
                setError(null);

                setRemoveDialogOpen(true);
              }}
            >
              <Trash2 />
              Remove member
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog
        open={roleDialogOpen}
        onOpenChange={(open) => {
          if (loading) {
            return;
          }

          setRoleDialogOpen(open);

          if (!open) {
            setError(null);

            setSelectedRoleId(member.role.id);
          }
        }}
      >
        <DialogContent showCloseButton={!loading}>
          <DialogHeader>
            <DialogTitle>Change member role</DialogTitle>

            <DialogDescription>
              Change the website role assigned to{" "}
              <strong>{member.user.name}</strong>.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label>Role</Label>

            <Select
              items={roleItems}
              value={selectedRoleId}
              onValueChange={setSelectedRoleId}
              disabled={loading}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select role" />
              </SelectTrigger>

              <SelectContent>
                {roles.map((role) => (
                  <SelectItem key={role.id} value={role.id}>
                    {role.name.replaceAll("_", " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              disabled={loading}
              onClick={() => setRoleDialogOpen(false)}
            >
              Cancel
            </Button>

            <Button
              type="button"
              disabled={
                loading || !selectedRoleId || selectedRoleId === member.role.id
              }
              onClick={() => void updateRole()}
            >
              Save changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={removeDialogOpen}
        onOpenChange={setRemoveDialogOpen}
        title="Remove member"
        description={`Remove ${member.user.name} from this website? Their account will remain available, but they will lose access to this website.`}
        confirmLabel="Remove member"
        destructive
        loading={loading}
        onConfirm={() => void removeMember()}
      />

      {error && !roleDialogOpen && !removeDialogOpen && (
        <p className="sr-only">{error}</p>
      )}
    </>
  );
}
