import { cache } from "react";
import { cookies } from "next/headers";

import { getCentralApiUrl } from "@/lib/auth/proxy";
import type { RolesResponse } from "@/lib/roles/types";

export const getServerRoles = cache(async (): Promise<RolesResponse> => {
  const cookieStore = await cookies();
  const cookieHeader = cookieStore
    .getAll()
    .map(({ name, value }) => `${name}=${value}`)
    .join("; ");

  if (!cookieHeader) {
    throw new Error("Authentication required");
  }

  const response = await fetch(`${getCentralApiUrl()}/api/v1/admin/roles`, {
    method: "GET",
    headers: { Cookie: cookieHeader },
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`Unable to load roles (${response.status})`);
  }

  return (await response.json()) as RolesResponse;
});
