import type { PaginationData } from "@/lib/data-table/types";
import type { AdminRole, AdminWebsiteStatus } from "@/lib/permissions/types";

export type InvitationStatus = "PENDING" | "USED" | "REVOKED" | "EXPIRED";

export interface InvitationUser {
  id: string;
  name: string;
  email: string;
  status: string;
  emailVerified: boolean;
}

export interface InvitationInviter {
  id: string;
  name: string;
  email: string;
}

export interface WebsiteInvitation {
  id: string;

  name: string;
  email: string;

  expiresAt: string;
  usedAt: string | null;
  revokedAt: string | null;

  createdAt: string;
  updatedAt: string;

  status: InvitationStatus;

  user: InvitationUser | null;

  role: AdminRole;

  invitedBy: InvitationInviter | null;
}

export interface WebsiteInvitationsResponse {
  success: boolean;

  data: WebsiteInvitation[];

  pagination: PaginationData;

  error?: string;
}

export interface CreateInvitationResponse {
  success: boolean;
  message?: string;
  error?: string;

  data?: {
    id: string;
    name: string;
    email: string;

    expiresAt: string;
    createdAt: string;

    invitationUrl?: string;
    token?: string;
  };
}

export interface InvitationMutationResponse {
  success: boolean;
  message?: string;
  error?: string;
}

/* ============================================================
 * PUBLIC INVITATION
 * ============================================================ */

export interface PublicInvitationWebsite {
  id: string;
  name: string;
  slug: string;
  status: AdminWebsiteStatus;
}

export interface PublicInvitationRole {
  id: string;
  name: string;
  description: string | null;
  scope: "WEBSITE";
}

export interface PublicInvitationInviter {
  id: string;
  name: string;
}

export interface VerifyInvitationData {
  invitationId: string;

  name: string;
  email: string;

  existingUser: boolean;

  requiresLogin: boolean;
  requiresPassword: boolean;

  website: PublicInvitationWebsite;

  role: PublicInvitationRole;

  invitedBy: PublicInvitationInviter | null;

  expiresAt: string;
}

export interface VerifyInvitationResponse {
  success: boolean;

  data?: VerifyInvitationData;

  error?: string;
  code?: string;
}

export interface ActivateInvitationData {
  user: {
    id: string;
    name: string;
    email: string;
    emailVerified: boolean;
    status: string;
  };

  website: {
    id: string;
    name: string;
    slug: string;
  };

  role: {
    id: string;
    name: string;
  };

  activatedAt: string;
}

export interface ActivateInvitationResponse {
  success: boolean;

  message?: string;

  data?: ActivateInvitationData;

  error?: string;
  code?: string;
}
