"use client";

import { Home, RefreshCcw, ServerCrash } from "lucide-react";

import Link from "next/link";

import { BackButton } from "@/components/common/state/back-button";

import { Button } from "@/components/ui/button";

import { TypographyMuted } from "@/components/ui/typography";

interface PageErrorProps {
  title?: string;
  description?: string;

  fullScreen?: boolean;

  reset?: () => void;

  showBackButton?: boolean;
  showDashboardButton?: boolean;
}

export function PageError({
  title = "Something went wrong",
  description = "An unexpected error occurred while processing your request. Please try again.",
  fullScreen = false,
  reset,
  showBackButton = true,
  showDashboardButton = true,
}: PageErrorProps) {
  return (
    <div
      role="alert"
      className={
        fullScreen
          ? "fixed inset-0 z-50 grid min-h-dvh w-full place-items-center bg-background px-6 text-foreground"
          : "grid min-h-[calc(100dvh-4rem)] w-full place-items-center bg-background px-6 text-foreground"
      }
    >
      <div className="w-full max-w-lg text-center">
        {/* ====================================================
            ICON
        ==================================================== */}

        <div className="relative mx-auto flex size-24 items-center justify-center">
          <div
            aria-hidden="true"
            className="absolute inset-0 rounded-full bg-destructive/10 blur-2xl"
          />

          <div className="relative flex size-16 items-center justify-center rounded-2xl border bg-card shadow-sm">
            <ServerCrash className="size-7 text-destructive" />
          </div>
        </div>

        {/* ====================================================
            ERROR CODE
        ==================================================== */}

        <p className="mt-8 font-mono text-xs font-bold uppercase tracking-[0.32em] text-destructive">
          Error 500
        </p>

        {/* ====================================================
            TITLE
        ==================================================== */}

        <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          {title}
        </h1>

        {/* ====================================================
            DESCRIPTION
        ==================================================== */}

        <TypographyMuted className="mx-auto mt-4 max-w-md font-sans text-sm leading-6 sm:text-base">
          {description}
        </TypographyMuted>

        {/* ====================================================
            ACTIONS
        ==================================================== */}

        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          {showBackButton && <BackButton />}

          {reset && (
            <Button type="button" onClick={reset}>
              <RefreshCcw className="size-4" />
              Try again
            </Button>
          )}

          {showDashboardButton && (
            <Button
              variant={reset ? "outline" : "default"}
              render={<Link href="/dashboard" />}
            >
              <Home className="size-4" />
              Dashboard
            </Button>
          )}
        </div>

        {/* ====================================================
            BRAND
        ==================================================== */}

        <TypographyMuted className="mt-10 font-mono text-[10px] uppercase tracking-[0.28em] opacity-50">
          Veyra · Create · Stream · Grow
        </TypographyMuted>
      </div>
    </div>
  );
}
