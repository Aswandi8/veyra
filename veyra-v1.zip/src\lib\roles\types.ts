export interface RoleListItem {
  id: string;
  name: string;
  description: string | null;
  createdAt: string;
  updatedAt: string;
  userCount: number;
  permissionCount: number;
}

export interface RolesResponse {
  success: boolean;
  data: RoleListItem[];
}
