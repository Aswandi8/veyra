"use client";

import {
  Edit3,
  Eye,
  MoreHorizontal,
  Trash2,
  Users,
  UserPlus,
} from "lucide-react";

import Link from "next/link";

import { useState } from "react";

import { useRouter } from "next/navigation";

import toast from "react-hot-toast";

import { ConfirmDialog } from "@/components/common/dialog/confirm-dialog";

import { Button } from "@/components/ui/button";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import type {
  WebsiteListItem,
  WebsiteMutationResponse,
} from "@/lib/websites/types";

interface WebsiteActionsProps {
  website: WebsiteListItem;

  canUpdate: boolean;
  canDelete: boolean;
}

export function WebsiteActions({
  website,
  canUpdate,
  canDelete,
}: WebsiteActionsProps) {
  const router = useRouter();

  const [deleteOpen, setDeleteOpen] = useState(false);

  const [deleting, setDeleting] = useState(false);

  async function deleteWebsite() {
    setDeleting(true);

    try {
      const response = await fetch(
        `/api/admin/websites/${encodeURIComponent(website.id)}`,
        {
          method: "DELETE",

          cache: "no-store",
        },
      );

      const contentType = response.headers.get("content-type") ?? "";

      if (!contentType.includes("application/json")) {
        toast.error("Server returned an invalid response.");

        return;
      }

      const result = (await response.json()) as WebsiteMutationResponse;

      if (!response.ok || !result.success) {
        toast.error(result.error ?? "Unable to delete website.");

        return;
      }

      setDeleteOpen(false);

      toast.success("Website deleted successfully.");

      router.refresh();
    } catch (error) {
      console.error("[DELETE WEBSITE]", error);

      toast.error("Central API is unavailable.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          render={
            <Button
              type="button"
              size="icon"
              variant="ghost"
              aria-label={`Actions for ${website.name}`}
            />
          }
        >
          <MoreHorizontal className="size-4" />
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end" className="min-w-48">
          <DropdownMenuItem render={<Link href={`/websites/${website.id}`} />}>
            <Eye />
            View details
          </DropdownMenuItem>

          <DropdownMenuItem
            render={<Link href={`/websites/${website.id}/members`} />}
          >
            <Users />
            Members
          </DropdownMenuItem>

          <DropdownMenuItem
            render={<Link href={`/websites/${website.id}/invitations`} />}
          >
            <UserPlus />
            Invitations
          </DropdownMenuItem>

          {canUpdate && (
            <>
              <DropdownMenuSeparator />

              <DropdownMenuItem
                render={<Link href={`/websites/${website.id}/edit`} />}
              >
                <Edit3 />
                Edit website
              </DropdownMenuItem>
            </>
          )}

          {canDelete && (
            <>
              <DropdownMenuSeparator />

              <DropdownMenuItem
                variant="destructive"
                onClick={() => setDeleteOpen(true)}
              >
                <Trash2 />
                Delete website
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <ConfirmDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        title="Delete website"
        description={`Delete ${website.name}? This action is only allowed if the website has no members, videos, categories, views, or API clients.`}
        confirmLabel="Delete website"
        destructive
        loading={deleting}
        onConfirm={() => void deleteWebsite()}
      />
    </>
  );
}
