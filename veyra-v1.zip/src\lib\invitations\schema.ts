import { z } from "zod";

export const invitationsQuerySchema = z.object({
  q: z.string().trim().max(100).default(""),

  page: z.coerce.number().int().min(1).default(1),

  limit: z.coerce.number().int().min(1).max(100).default(20),

  status: z.enum(["PENDING", "USED", "REVOKED", "EXPIRED"]).optional(),

  role: z.string().trim().min(1).optional(),
});

export const createInvitationSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),

  email: z.string().trim().email("Enter a valid email address"),

  roleId: z.string().trim().min(1, "Role is required"),
});

export type InvitationsQuery = z.infer<typeof invitationsQuerySchema>;

export type CreateInvitationValues = z.infer<typeof createInvitationSchema>;
