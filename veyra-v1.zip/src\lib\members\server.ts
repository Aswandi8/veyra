import { cache } from "react";

import { cookies } from "next/headers";

import { getCentralApiUrl } from "@/lib/auth/proxy";

import type {
  WebsiteMembersResponse,
  WebsiteRolesResponse,
} from "@/lib/members/types";

export const getServerWebsiteMembers = cache(
  async (
    websiteId: string,
    q: string,
    page: number,
    limit: number,
    role?: string,
  ): Promise<WebsiteMembersResponse> => {
    const cookieStore = await cookies();

    const cookieHeader = cookieStore
      .getAll()
      .map(({ name, value }) => `${name}=${value}`)
      .join("; ");

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
    });

    if (q) {
      params.set("q", q);
    }

    if (role) {
      params.set("role", role);
    }

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(
        websiteId,
      )}/users?${params.toString()}`,
      {
        method: "GET",

        headers: {
          Cookie: cookieHeader,
          Accept: "application/json",
        },

        cache: "no-store",
      },
    );

    if (!response.ok) {
      throw new Error(`Unable to load website members (${response.status})`);
    }

    return (await response.json()) as WebsiteMembersResponse;
  },
);

export const getServerWebsiteRoles = cache(
  async (websiteId: string): Promise<WebsiteRolesResponse> => {
    const cookieStore = await cookies();

    const cookieHeader = cookieStore
      .getAll()
      .map(({ name, value }) => `${name}=${value}`)
      .join("; ");

    if (!cookieHeader) {
      throw new Error("Authentication required");
    }

    const response = await fetch(
      `${getCentralApiUrl()}/api/v1/admin/websites/${encodeURIComponent(
        websiteId,
      )}/roles`,
      {
        method: "GET",

        headers: {
          Cookie: cookieHeader,
          Accept: "application/json",
        },

        cache: "no-store",
      },
    );

    if (!response.ok) {
      throw new Error(`Unable to load website roles (${response.status})`);
    }

    return (await response.json()) as WebsiteRolesResponse;
  },
);
